/* public/js/chat.js
 * ─────────────────────────────────────────────────────────────
 * CHAT LOG + UNREAD BADGES + EPHEMERAL SYSTEM NOTICES.
 *
 * Three cooperating pieces, all previously inline in room.js:
 *
 *  1. Message log
 *     buildMsgEl(msg)        one .chat-msg row (avatar button carries
 *                            data-uid/data-uname for the profile card; the
 *                            click delegate for it still lives in the
 *                            permissions/profile code)
 *     appendMessage(msg,auto)  new live message; measures stickiness BEFORE
 *                            inserting so the log only auto-scrolls when the
 *                            user was already at the bottom
 *     addSystemMsg(text,opts)  grey .chat-sys line; opts.silent = "I did this",
 *                            opts.persist = never auto-expire, opts.ttl,
 *                            opts.cls; returns the element
 *     regroupChat()          re-applies .grouped to consecutive same-sender
 *                            messages inside GROUP_WINDOW
 *     loadInitialMessages()  first 20 via REST, then scroll to bottom
 *     onChatScroll()         infinite scroll upward + Unread/SYS bookkeeping
 *     showTopLoader/hideTopLoader/markStartReached
 *     sendMessage()          emits 'chat-message', clears the input
 *
 *  2. Unread  — the unread counter shared by the Chat tab badge, the
 *     "jump to latest" pill and document.title.
 *       .n      unread count      .stick  should the log snap to bottom when shown
 *       note()  register a new line (returns true if the user should be nudged)
 *       drop()  give a point back when an unseen notice expires
 *       sync()/clear()/jump()/onChatShown()/onScroll()/paint()
 *
 *  3. SYS  — self-destructing system notices so the log stays readable.
 *     Expiry order == insertion order; invisible notices are yanked instantly,
 *     visible ones get at most one animated collapse at a time, never while
 *     the user is actively scrolling (SCROLL_HOLD).
 *
 * Module-private state (was module-scope `let`s in room.js):
 *     oldestMsgId, hasMoreMsgs, loadingOlder, startMarkerShown
 *
 * Network: subscribes to the centralized hooks (onRoomState / onUserJoined /
 * onUserLeft) and attaches its own domain listeners ('chat-message',
 * 'chat-system') on first connect. socket-core NEVER imports this file.
 *
 * DOM: dom.chatMsgs, dom.chatInput, dom.chatUnread, dom.chatJump,
 *      dom.chatJumpN, dom.tabChat, dom.paneChat
 * ───────────────────────────────────────────────────────────── */
"use strict";
import { roomId, GROUP_WINDOW, GIF_INSTANT_SEND } from "./config.js";
import { S } from "./state.js";
import { $, dom } from "./dom.js";
import { esc, fmtMsgStamp, fmtMsgFull, fmtBadge, isMe, delay } from "./utils.js";
import { getSocket, emit as sockEmit } from "./socket-ref.js";
import { onConnect, onRoomState, onUserJoined, onUserLeft } from "./socket-core.js";
import { normalizeImageUrl } from "./chat_modules/media-embed.js";
import { wireGifPicker, closeGifPicker } from "./chat_modules/gif-picker.js";
import { wireAttachments, takeOutgoing, resetAttachments, stageGif, suspendAttachments } from "./chat_modules/chat-attach.js";
import { wireLightbox } from "../shared/lightbox.js";
import { wireSysLog, isSysView, setSysView, setToolsMode, closeChatTools, onSysPaneShown } from "./chat_modules/sys-log.js";
import { avatarHTML, nameOf, ensureIdentities } from "../shared/identity.js";
import { onTabChange } from "./side-tabs.js";

/* ── history pagination bookkeeping ── */
let startMarkerShown = false;
let oldestMsgId = null, hasMoreMsgs = false, loadingOlder = false;
/* messages I've reported this session (the server dedupes too) */
const reportedIds = new Set();

// helpers

/* role of a sender from the viewer's member list */
function roleOfUid(uid) {
  if (!uid) return "member";
  const adminId = S.room && S.room.admin && S.room.admin.userId;
  if (adminId && String(adminId) === uid) return "admin";
  const m = (S.members || []).find((x) => String(x.userId) === uid);
  return m && (m.role === "admin" || m.role === "mod") ? m.role : "member";
}
function paintRole(el) {
  const r = roleOfUid(el.dataset.senderId);
  if (el.dataset.role !== r) el.dataset.role = r;
}

/* ══════════════════════════════════════
   SIDE-PANEL BADGES (unread chat/room updates)
   ══════════════════════════════════════ */
export const Unread = {
  n: 0,
  stick: true,            // should the log snap to the bottom next time it's shown?
  _title: document.title,
  _raf: 0,
  chatOnScreen() { return dom.paneChat.classList.contains("active") && !isSysView(); },
  atBottom(slack) {
    const el = dom.chatMsgs;
    return el.scrollHeight - el.scrollTop - el.clientHeight <= (slack == null ? 120 : slack);
  },
  /* "the user is demonstrably looking at the newest line" */
  watching() { return !document.hidden && this.chatOnScreen() && this.atBottom(); },
  toEnd() { dom.chatMsgs.scrollTop = dom.chatMsgs.scrollHeight; },
  /* ── called for every NEW line appended to the log (never for history) ── */
  note(opts) {
    opts = opts || {};
    if (opts.stick !== undefined) this.stick = !!opts.stick;
    if (opts.silent) return false;                 // my own message / my own action
    if (this.watching()) return false;             // already on screen at the bottom
    this.n++;
    this.paint();
    return true;                                     // user should be notified
  },
  /* an unseen notice expired → give the badge its point back */
  drop(k) {
    if (!this.n) return;
    this.n = Math.max(0, this.n - (k || 1));
    this.paint();
  },
  /* once the user has seen everything, no element may claim "unread" later */
  _forget() {
    dom.chatMsgs.querySelectorAll("[data-unread]").forEach((el) => delete el.dataset.unread);
  },
  clear() { this.n = 0; this._forget(); this.paint(); },
  sync()  { if (this.watching()) { this.n = 0; this._forget(); } this.paint(); },
  /* chat pane just became visible */
  onChatShown() {
    if (this.stick) this.toEnd();            // content added while display:none loses scrollTop
    this.sync();
  },
  onScroll() {
    if (this._raf) return;
    this._raf = requestAnimationFrame(() => {
      this._raf = 0;
      if (this.chatOnScreen()) this.stick = this.atBottom();
      this.sync();
    });
  },
  jump() { this.toEnd(); this.clear(); },
  paint() {
    const n = this.n, label = fmtBadge(n);
    dom.chatUnread.hidden      = n === 0;
    dom.chatUnread.textContent = label;
    dom.chatUnread.title       = n === 1 ? "1 new update" : n + " new updates";
    dom.tabChat.classList.toggle("has-unread", n > 0);
    dom.tabChat.setAttribute("aria-label", n ? "Chat, " + label + " new updates" : "Chat");
    /* pill only makes sense while the chat is on screen but scrolled away */
    const showPill = n > 0 && this.chatOnScreen() && !this.atBottom();
    dom.chatJump.hidden = !showPill;
    dom.chatJumpN.textContent = label;
    document.title = n > 0 ? "(" + label + ") " + this._title : this._title;
  },
};
/* ══════════════════════════════════════
   EPHEMERAL SYSTEM LOG — notices self-destruct so chat stays readable
   ══════════════════════════════════════ */
export const SYS = {
  TTL:      5 * 1000,  // lifetime of a notice
  GAP:      1000,           // min *stillness* between two animated removals
  OUT_MS:   560,            // must be ≥ the CSS exit duration (500ms) + slack
  SCROLL_HOLD: 1200,        // never animate right after the user scrolled
  MAX_LIVE: 15,             // burst guard: pull in expiry when notices pile up
  EARLY:    8000,
  items: [],                // [{el, exp}] — insertion order == expiry order
  timer: 0, lastOut: 0, holdUntil: 0, animating: false,
  /* ── register a notice ── */
  track(el, ttl) {
    this.items.push({ el, exp: Date.now() + (ttl || this.TTL) });
    this.trim();
    this.schedule();
  },
  /* a wall of notices shouldn't sit around for the full 5 min */
  trim() {
    const over = this.items.length - this.MAX_LIVE;
    if (over <= 0) return;
    const soon = Date.now() + this.EARLY;
    for (let i = 0; i < over; i++)
      if (this.items[i].exp > soon) this.items[i].exp = soon;
  },
  hold(ms) { this.holdUntil = Math.max(this.holdUntil, Date.now() + ms); },
  schedule() {
    clearTimeout(this.timer); this.timer = 0;
    if (this.animating || !this.items.length) return;
    this.timer = setTimeout(() => this.sweep(), Math.max(this.items[0].exp - Date.now(), 50));
  },
  sweep() {
    clearTimeout(this.timer); this.timer = 0;
    if (this.animating) return;                       // the callback re-arms us
    const now = Date.now();
    let pending = null;
    /* everything the user can't see goes instantly & silently */
    while (this.items.length) {
      const it = this.items[0];
      if (!it.el.isConnected) { this.items.shift(); continue; }
      if (it.exp > now) break;                        // ordered ⇒ nothing else is due
      if (this.visible(it.el)) { pending = it; break; }
      this.items.shift();
      this.yank(it.el);
    }
    /* at most ONE animated removal, and only when the view is calm */
    if (pending) {
      const wait = Math.max(this.GAP - (now - this.lastOut), this.holdUntil - now);
      if (wait > 0) { this.timer = setTimeout(() => this.sweep(), wait); return; }
      this.items.shift();
      this.animating = true;
      this.fade(pending.el, () => {
        this.animating = false;
        this.lastOut  = Date.now();                   // 2s of stillness AFTER the collapse
        this.schedule();
      });
      return;
    }
    this.schedule();
  },
  /* is this notice actually on screen *and* being looked at? */
  visible(el) {
    if (document.hidden) return false;
    if (!Unread.chatOnScreen()) return false;          // other tab, or the Sys view is up
    const c = dom.chatMsgs;
    if (!c.clientHeight || !el.offsetParent) return false;   // display:none ⇒ not rendered
    const r = el.getBoundingClientRect(), cr = c.getBoundingClientRect();
    return r.bottom > cr.top + 4 && r.top < cr.bottom - 4;
  },
  /* instant removal, scroll-stable, badge-accurate */
  yank(el) {
    const c = dom.chatMsgs;
    const shown  = dom.paneChat.classList.contains("active") && c.clientHeight > 0;
    const above  = shown && el.getBoundingClientRect().bottom <= c.getBoundingClientRect().top;
    const before = shown ? c.scrollHeight : 0;
    const top    = c.scrollTop;
    this.uncount(el);
    el.remove();
    if (above) {                                      // content above the viewport vanished →
      const delta = before - c.scrollHeight;          // pull scrollTop back by exactly that much
      if (delta > 0) c.scrollTop = Math.max(0, top - delta);
    }
  },
  /* animated removal: fade, then collapse the gap */
  fade(el, done) {
    const c = dom.chatMsgs;
    const pinned = Unread.atBottom(8);
    el.style.height   = el.offsetHeight + "px";       // height:auto can't transition
    el.style.overflow = "hidden";
    void el.offsetHeight;                             // commit the start height
    el.classList.add("sys-out");
    el.style.height   = "0px";                        // …now the delayed collapse runs
    /* hold the bottom while the gap closes so the log never "drops" */
    let stop = false;
    if (pinned) {
      const keep = () => { if (stop) return; c.scrollTop = c.scrollHeight; requestAnimationFrame(keep); };
      requestAnimationFrame(keep);
    }
    setTimeout(() => {
      stop = true;
      this.uncount(el);
      el.remove();
      if (pinned) c.scrollTop = c.scrollHeight;
      done && done();
    }, this.OUT_MS);
  },
  /* a notice that dies unseen must not leave a ghost on the tab badge */
  uncount(el) {
    if (el.dataset.unread === "1") { delete el.dataset.unread; Unread.drop(1); }
  },
};

function onGifPicked({ url }) {
  if (isSysView()) return;
  const clean = normalizeImageUrl(url);
  if (!clean) return;
  if (!GIF_INSTANT_SEND) {
    stageGif(clean);                                       // joins the thumbnail row
    dom.chatInput.focus();
    return;
  }
  if (!getSocket()) return;
  sockEmit("chat-message", { text: "", mediaUrl: clean }); // the typed draft stays untouched
  Unread.stick = true;
  Unread.clear();
  if (matchMedia("(hover: hover)").matches) dom.chatInput.focus();
}
/* ══════════════════════════════════════
   MESSAGE MEDIA — <img class="msg-media"> under .msg-text
   Images change height when they load. A ResizeObserver keeps the log
   stable: pinned → stay pinned; growth ABOVE the viewport → compensate
   scrollTop so what you're reading doesn't jump.
   ══════════════════════════════════════ */
const mediaRO = typeof ResizeObserver === "function" ? new ResizeObserver(onMediaResize) : null;
const mediaH  = new WeakMap();
function onMediaResize(entries) {
  const c = dom.chatMsgs;
  if (!c.clientHeight) return;                   // pane hidden → every size is 0, ignore
  const viewTop = c.getBoundingClientRect().top;
  let shift = 0, changed = false;
  for (const { target } of entries) {
    if (!target.isConnected) continue;
    const h = target.offsetHeight, prev = mediaH.get(target);
    mediaH.set(target, h);
    if (prev === undefined || prev === h) continue;
    changed = true;
    if (target.getBoundingClientRect().top < viewTop) shift += h - prev;
  }
  if (!changed) return;
  if (Unread.stick) Unread.toEnd();
  else if (shift) c.scrollTop += shift;
}
function mediaHTML(url) {
  if (!url) return "";
  const u = esc(url);
  return '<div class="msg-media-wrap loading">' +
    '<a class="msg-media-link" href="' + u + '" target="_blank" rel="noopener noreferrer nofollow" ' +
       'aria-label="View image">' +
      '<img class="msg-media" src="' + u + '" alt="" loading="lazy" decoding="async" ' +
           'referrerpolicy="no-referrer" draggable="false">' +
    "</a></div>";
}
function mountMedia(row) {
  const wrap = row.querySelector(".msg-media-wrap");
  const img  = wrap && wrap.querySelector(".msg-media");
  if (!img) return;
  img.addEventListener("load", () => wrap.classList.remove("loading"), { once: true });
  img.addEventListener("error", () => {
    const url = img.getAttribute("src") || "";
    wrap.className = "msg-media-wrap broken";
    wrap.innerHTML = '<a class="msg-media-fallback" href="' + esc(url) + '" target="_blank" ' +
                     'rel="noopener noreferrer nofollow">🖼️ Image unavailable</a>';
  }, { once: true });
  if (mediaRO) mediaRO.observe(wrap);
}
/* scroll-stable removal (used on delete) */
function removeMedia(row) {
  const wrap = row.querySelector(".msg-media-wrap");
  if (!wrap) return;
  const c = dom.chatMsgs;
  const above  = c.clientHeight > 0 && wrap.getBoundingClientRect().top < c.getBoundingClientRect().top;
  const before = c.scrollHeight, top = c.scrollTop;
  if (mediaRO) mediaRO.unobserve(wrap);
  wrap.remove();
  if (above) c.scrollTop = Math.max(0, top - (before - c.scrollHeight));
}
/* ═══════ CHAT ═══════ */
export function sendMessage() {
  if (!getSocket() || isSysView()) return;
  /* [{ text, mediaUrl: img1 }, { text: "", mediaUrl: img2 }, …] — one message per image */
  const batch = takeOutgoing();
  if (!batch.length) return;
  batch.forEach((payload) => sockEmit("chat-message", payload));  // server keeps them in order
  dom.chatInput.value = "";
  resetAttachments();
  growChatInput();
  dom.chatInput.focus();
  Unread.stick = true;
  Unread.clear();
}
export async function loadInitialMessages() {
  try {
    const r = await fetch("/api/rooms/" + roomId + "/messages?limit=20", { credentials: "include" });
    if (!r.ok) return;
    const d = await r.json();
    hasMoreMsgs = d.hasMore;
    oldestMsgId = d.messages.length ? d.messages[0].id : null;
    const frag = document.createDocumentFragment();
    d.messages.forEach((m) => frag.appendChild(buildMsgEl(m)));
    dom.chatMsgs.appendChild(frag);
    regroupChat();
    dom.chatMsgs.scrollTop = dom.chatMsgs.scrollHeight;
    if (!hasMoreMsgs) markStartReached();
  } catch (_) {}
}
/* fetch ONE older page and prepend it, keeping the scroll position.
   Resolves true if a page was loaded. */
async function loadOlderPage(minDelay) {
  if (loadingOlder || !hasMoreMsgs || !oldestMsgId) return false;
  loadingOlder = true;
  const prev = dom.chatMsgs.scrollHeight;
  showTopLoader();
  let ok = false;
  try {
    const fp = fetch("/api/rooms/" + roomId + "/messages?limit=20&before=" + oldestMsgId,
                     { credentials: "include" })
      .then((r) => { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); });
    const d = (await Promise.all([fp, delay(minDelay || 0)]))[0];
    hasMoreMsgs = d.hasMore;
    hideTopLoader();
    if (d.messages.length) {
      oldestMsgId = d.messages[0].id;
      const frag = document.createDocumentFragment();
      d.messages.forEach((m) => frag.appendChild(buildMsgEl(m)));
      dom.chatMsgs.insertBefore(frag, dom.chatMsgs.firstChild);
      regroupChat();
      dom.chatMsgs.scrollTop = dom.chatMsgs.scrollHeight - prev;
    }
    if (!hasMoreMsgs) markStartReached();
    ok = true;
  } catch (_) { hideTopLoader(); }
  loadingOlder = false;
  return ok;
}
export async function onChatScroll() {
  Unread.onScroll();
  SYS.hold(SYS.SCROLL_HOLD);            // never collapse under a moving finger
  if (dom.chatMsgs.scrollTop > 40) return;
  await loadOlderPage(450);
}
/* who can act on a message, from the viewer's seat */
function msgPerms(msg) {
  const mine = isMe(msg.senderId);
  const mod  = !!(S.perms && S.perms.canManage);
  return {
    mine,
    canEdit:   mine && !msg.deleted,
    canDelete: !msg.deleted && (mine || mod),
    /* mods/host delete directly; reporting would only notify themselves */
    canReport: !mine && !mod && !msg.deleted && !!msg.senderId,
  };
}
function deletedByText(msg) {
  const role = msg.deletedByRole, name = msg.deletedByName;
  if (!role || role === "self") return "";
  return " by " + esc(name || (role === "admin" ? "the host" : "a moderator"));
}
function msgBubbleHTML(msg) {
  if (msg.deleted)
    return '<div class="msg-text msg-deleted">Message deleted' + deletedByText(msg) + "</div>";
  return '<div class="msg-text">' + esc(msg.text || "") +
    (msg.editedAt
      ? ' <span class="msg-edited" title="' + esc("Edited " + fmtMsgFull(msg.editedAt)) + '">(edited)</span>'
      : "") +
    "</div>";
}
/* reconstruct a minimal msg object from a rendered row */
function readMsg(el) {
  return {
    id:            el.dataset.id,
    senderId:      el.dataset.senderId || null,
    deleted:       el.classList.contains("deleted"),
    editedAt:      el.dataset.edited ? 1 : null,
    hasMedia:      el.dataset.media === "1",
    deletedByRole: el.dataset.delRole || null,
    deletedByName: el.dataset.delName || null,
  };
}
export function buildMsgEl(msg) {
  const self = msg.senderId && S.userId && msg.senderId.toString() === S.userId;
  const uid  = msg.senderId ? msg.senderId.toString() : "";
  const name = uid ? nameOf(uid, msg.username) : (msg.username || "");   // current name, not the one stored on the message
  /* re-validate even server data: only https image links ever reach an <img> */
  const media  = !msg.deleted ? normalizeImageUrl(msg.mediaUrl) : null;
  const noText = !msg.deleted && !(msg.text && String(msg.text).trim());
  const div = document.createElement("div");
  div.className = "chat-msg" + (self ? " self" : "") + (msg.deleted ? " deleted" : "") +
                  (media ? " has-media" : "") + (noText ? " no-text" : "");
  div.dataset.sender   = msg.senderId || msg.username;
  div.dataset.senderId = uid;
  div.dataset.role     = roleOfUid(uid);
  div.dataset.id       = msg.id || "";
  div.dataset.ts       = new Date(msg.timestamp || Date.now()).getTime();
  if (media)             div.dataset.media   = "1";
  if (msg.editedAt)      div.dataset.edited  = "1";
  if (msg.deletedByRole) div.dataset.delRole = msg.deletedByRole;
  if (msg.deletedByName) div.dataset.delName = msg.deletedByName;
  const av = uid
    ? avatarHTML({
        uid, name, tag: "button", cls: "msg-av",
        attrs: 'type="button" data-uid="' + esc(uid) + '" data-uname="' + esc(name) + '" ' +
               'title="View profile" aria-label="View profile of ' + esc(name || "user") + '"',
      })
    : avatarHTML({ name, tag: "div", cls: "msg-av" });
  div.innerHTML =
    av +
    '<div class="msg-body">' +
      '<div class="msg-head">' +
        '<span class="msg-name' + (self ? " self" : "") + '"' +
          (uid ? ' data-name-uid="' + esc(uid) + '"' : "") + ">" + esc(name) + "</span>" +
        '<time class="msg-ts" datetime="' + new Date(msg.timestamp || Date.now()).toISOString() +
          '" title="' + esc(fmtMsgFull(msg.timestamp)) + '">' + esc(fmtMsgStamp(msg.timestamp)) + "</time>" +
      "</div>" +
      '<div class="msg-line">' + msgBubbleHTML(msg) + "</div>" +
      mediaHTML(media) +
    "</div>";
  if (media) mountMedia(div);
  wireRowInteraction(div);
  if (uid) ensureIdentities([uid]);          // batched: 20 history messages → 1 request
  return div;
}
/* ── right-click (desktop) + long-press (touch) open the same menu ──
   Listeners read live state through readMsg(), so they survive edit/delete
   repaints and late role changes without being re-attached. */
function actionable(el) {
  if (el.classList.contains("editing")) return false;
  const p = msgPerms(readMsg(el));
  return p.canEdit || p.canDelete || p.canReport;
}
function wireRowInteraction(el) {
  /* desktop: replace the native context menu */
  el.addEventListener("contextmenu", (e) => {
    if (e.target.closest(".msg-edit") || e.target.closest(".msg-av")) return;
    e.preventDefault();                       // no "Inspect / Save image / …"
    if (!actionable(el)) return;
    MsgMenu.open(el, { x: e.clientX, y: e.clientY });
  });
  /* touch: press-and-hold */
  let timer = 0, sx = 0, sy = 0, fired = false;
  const reset = () => { clearTimeout(timer); timer = 0; el.classList.remove("pressing"); };
  el.addEventListener("touchstart", (e) => {
    if (e.touches.length !== 1) return;
    if (e.target.closest(".msg-edit") || e.target.closest(".msg-av")) return;
    if (!actionable(el)) return;
    fired = false;
    sx = e.touches[0].clientX;
    sy = e.touches[0].clientY;
    el.classList.add("pressing");             // immediate feedback, WhatsApp-style
    timer = setTimeout(() => {
      fired = true;
      el.classList.remove("pressing");
      if (navigator.vibrate) navigator.vibrate(12);
      MsgMenu.open(el, { x: sx, y: sy });
    }, 450);
  }, { passive: true });
  el.addEventListener("touchmove", (e) => {
    if (!timer) return;
    if (Math.abs(e.touches[0].clientX - sx) > 10 ||
        Math.abs(e.touches[0].clientY - sy) > 10) reset();   // it's a scroll, not a press
  }, { passive: true });
  el.addEventListener("touchend", (e) => {
    if (fired) e.preventDefault();             // swallow the emulated click
    reset();
  });
  el.addEventListener("touchcancel", reset);
}

export function appendMessage(msg, auto) {
  const self = isMe(msg.senderId);
  const stick = self || Unread.atBottom();          // measure BEFORE inserting
  dom.chatMsgs.appendChild(buildMsgEl(msg));
  regroupChat();
  if (auto && stick) Unread.toEnd();
  Unread.note({ silent: self, stick });
}
/* opts.silent → this line describes something *I* just did */
export function addSystemMsg(text, opts) {
  opts = opts || {};
  const stick = Unread.atBottom();
  const div = document.createElement("div");
  div.className = "chat-sys" + (opts.cls ? " " + opts.cls : "");
  div.textContent = text;
  dom.chatMsgs.appendChild(div);
  if (stick) Unread.toEnd();
  if (Unread.note({ silent: !!opts.silent, stick })) div.dataset.unread = "1";
  if (!opts.persist) SYS.track(div, opts.ttl);        // ← auto-expires
  return div;
}
// Marks consecutive same-sender messages as grouped
export function regroupChat() {
  let prev = null;
  Array.from(dom.chatMsgs.children).forEach((el) => {
    if (!el.classList.contains("chat-msg")) { prev = null; return; } // sys msgs / loaders break grouping
    const sender = el.dataset.sender, ts = parseInt(el.dataset.ts, 10);
    const grouped = prev && prev.sender === sender && !isNaN(ts) && (ts - prev.ts) < GROUP_WINDOW;
    el.classList.toggle("grouped", grouped);
    prev = { sender, ts };
  });
}
// "Loading earlier messages…" loader at the top of the chat
export function showTopLoader() {
  if (dom.chatMsgs.querySelector(".chat-loader")) return;
  const el = document.createElement("div");
  el.className = "chat-loader";
  el.innerHTML = '<span class="chat-spinner"></span><span>Loading earlier messages…</span>';
  dom.chatMsgs.insertBefore(el, dom.chatMsgs.firstChild);
}
export function hideTopLoader() { const el = dom.chatMsgs.querySelector(".chat-loader"); if (el) el.remove(); }
export function markStartReached() {
  if (startMarkerShown) return;
  startMarkerShown = true;
  const el = document.createElement("div");
  el.className = "chat-start";
  el.textContent = "✨ This is the beginning of the conversation";
  dom.chatMsgs.insertBefore(el, dom.chatMsgs.firstChild);
}
/*
   New delete/edit chat messages functionality and helper functions
*/
function cssEsc(s) {
  return (window.CSS && CSS.escape) ? CSS.escape(s) : String(s).replace(/["\\]/g, "\\$&");
}
function rowById(id) {
  return id ? dom.chatMsgs.querySelector('.chat-msg[data-id="' + cssEsc(id) + '"]') : null;
}
function liveText(el) {
  const t = el.querySelector(".msg-text");
  if (!t) return "";
  const clone = t.cloneNode(true);
  const tag = clone.querySelector(".msg-edited");
  if (tag) tag.remove();
  return clone.textContent.trim();
}
const nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));
/* Bring a message on screen and flash it. Pages back through history if it
   isn't loaded yet. Resolves false if the message isn't in the log. */
export async function jumpToMessage(id) {
  if (!id) return false;
  if (isSysView()) setSysView(false);                     // e.g. opened from a report
  /* show the chat pane (goes through the normal tab handlers) */
  if (!dom.paneChat.classList.contains("active")) dom.tabChat.click();
  let row = rowById(id);
  for (let guard = 0; !row && guard < 50; guard++) {
    while (loadingOlder) await delay(60);          // a scroll-triggered fetch is in flight
    row = rowById(id);
    if (row || !hasMoreMsgs || !oldestMsgId) break;
    if (!(await loadOlderPage(0))) break;
    row = rowById(id);
  }
  if (!row) return false;
  /* wait past the tab-switch rAF (Unread.onChatShown may snap to the bottom) */
  await nextFrame(); await nextFrame();
  SYS.hold(2500);                                   // don't collapse notices mid-scroll
  row.scrollIntoView({ block: "center", behavior: "smooth" });
  row.classList.remove("msg-flash");
  void row.offsetWidth;                             // restart the animation
  row.classList.add("msg-flash");
  clearTimeout(row._flashT);
  row._flashT = setTimeout(() => row.classList.remove("msg-flash"), 2200);
  return true;
}
/* grow a textarea to fit its content, up to its CSS max-height (or `cap`) */
function autoGrow(ta, cap) {
  const max = cap || parseFloat(getComputedStyle(ta).maxHeight) || 140;
  ta.style.height = "auto";
  const border = ta.offsetHeight - ta.clientHeight;
  const full   = ta.scrollHeight + border;
  ta.style.height    = Math.min(full, max) + "px";
  ta.style.overflowY = full > max ? "auto" : "hidden";
}
/* the composer grows upward and squeezes the log; keep the log pinned */
function growChatInput() {
  const pinned = Unread.atBottom(8);
  autoGrow(dom.chatInput);
  if (pinned) Unread.toEnd();
}
/* Sys view: keep the row, make it read-only. The draft is parked so the
   placeholder is visible, then restored (with its caret) on the way back. */
const READ_ONLY_PH = "System Transcript - Read Only";
let parkedDraft = null, normalPh = null;
function lockComposer(locked) {
  const ta = dom.chatInput, send = $("sendBtn"), gif = $("gifBtn");
  if (locked) {
    closeGifPicker();
    suspendAttachments(true);
    if (parkedDraft === null)
      parkedDraft = { value: ta.value, s: ta.selectionStart, e: ta.selectionEnd };
    if (normalPh === null) normalPh = ta.placeholder;
    ta.value = "";
    ta.placeholder = READ_ONLY_PH;
    ta.disabled = true;
  } else {
    ta.disabled = false;
    if (normalPh !== null) ta.placeholder = normalPh;
    if (parkedDraft) {
      ta.value = parkedDraft.value;                        // same string → attachment anchors stay valid
      try { ta.setSelectionRange(parkedDraft.s, parkedDraft.e); } catch (_) {}
      parkedDraft = null;
    }
    suspendAttachments(false);
  }
  send.disabled = locked;
  if (gif) gif.disabled = locked;
  autoGrow(ta);
}
function enterEdit(el) {
  if (!el || el.classList.contains("editing") || el.classList.contains("deleted")) return;
  const textEl = el.querySelector(".msg-text");
  if (!textEl) return;
  const current = liveText(el);
  el.classList.add("editing");
  const box = document.createElement("div");
  box.className = "msg-edit";
  box.innerHTML =
    '<textarea class="msg-edit-input" maxlength="500" rows="1"></textarea>' +
    '<div class="msg-edit-actions">' +
      '<button type="button" class="msg-edit-cancel">Cancel</button>' +
      '<button type="button" class="msg-edit-save">Save</button>' +
    "</div>";
  (el.querySelector(".msg-line") || textEl).after(box);
  const ta = box.querySelector("textarea");
  ta.value = current;
  autoGrow(ta);
  ta.focus();
  ta.setSelectionRange(current.length, current.length);
  const cancel = () => exitEdit(el);
  const save = () => {
    const next = ta.value.trim();
    const hasMedia = el.dataset.media === "1";             // a GIF/image can live without a caption
    if ((next || hasMedia) && next !== current && getSocket())
      sockEmit("chat-edit", { id: el.dataset.id, text: next });
    exitEdit(el);                                          // server broadcast repaints the bubble
  };
  box.querySelector(".msg-edit-cancel").onclick = cancel;
  box.querySelector(".msg-edit-save").onclick   = save;
  ta.addEventListener("input", () => autoGrow(ta));
  ta.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { e.preventDefault(); cancel(); }
    else if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); save(); }
  });
}
function exitEdit(el) {
  if (!el) return;
  el.classList.remove("editing");
  const box = el.querySelector(".msg-edit");
  if (box) box.remove();
}
const MsgMenu = {
  el: null, forId: null, rowEl: null, _openedAt: 0,
  ensure() {
    if (this.el) return this.el;
    const m = document.createElement("div");
    m.className = "msg-menu";
    m.hidden = true;
    m.addEventListener("contextmenu", (e) => e.preventDefault());
    (document.getElementById("roomPage") || document.body).appendChild(m);  // ← theme vars now reach it
    this.el = m;
    return m;
  },
  /* pos = { x, y } pointer/touch point  OR  { anchor: el } (the 3-dot button) */
  open(row, pos) {
    const id = row.dataset.id;
    if (!id) return;
    if (this.forId === id && !this.el.hidden && pos && pos.anchor) { this.close(); return; }
    const p = msgPerms(readMsg(row));
    let html = "";
    if (p.canEdit)
      html += '<button type="button" class="msg-menu-item" data-act="edit">Edit</button>';
    if (p.canReport) {
      html += reportedIds.has(id)
        ? '<button type="button" class="msg-menu-item" disabled>Reported ✓</button>'
        : '<button type="button" class="msg-menu-item" data-act="report">Report</button>' +
          '<div class="msg-menu-confirm" data-confirm="report" hidden>' +
            "<span>Report this message to the host &amp; mods?</span>" +
            '<button type="button" class="msg-menu-item danger" data-act="rep-yes">Yes, report</button>' +
            '<button type="button" class="msg-menu-item" data-act="confirm-no">Cancel</button>' +
          "</div>";
    }
    if (p.canDelete)
      html +=
        '<button type="button" class="msg-menu-item danger" data-act="del">Delete</button>' +
        '<div class="msg-menu-confirm" data-confirm="del" hidden>' +
          "<span>Delete this message?</span>" +
          '<button type="button" class="msg-menu-item danger" data-act="del-yes">Yes, delete</button>' +
          '<button type="button" class="msg-menu-item" data-act="confirm-no">Cancel</button>' +
        "</div>";
    if (!html) return;
    if (this.rowEl) this.rowEl.classList.remove("menu-target");
    const m = this.ensure();
    m.innerHTML = html;
    m.hidden = false;
    this.forId = id;
    this.rowEl = row;
    this._openedAt = Date.now();
    row.classList.add("menu-target");
    const pad = 8, mw = m.offsetWidth, mh = m.offsetHeight;
    const vw = window.innerWidth, vh = window.innerHeight;
    let left, top;
    if (pos && pos.anchor) {
      const r = pos.anchor.getBoundingClientRect();
      left = r.right - mw;
      top  = (r.bottom + 4 + mh > vh - pad) ? r.top - mh - 4 : r.bottom + 4;
    } else {
      left = (pos ? pos.x : vw / 2);
      top  = (pos ? pos.y : vh / 2);
      if (left + mw > vw - pad) left -= mw;
      if (top  + mh > vh - pad) top  -= mh;
    }
    m.style.left = Math.round(Math.min(Math.max(pad, left), vw - mw - pad)) + "px";
    m.style.top  = Math.round(Math.min(Math.max(pad, top),  vh - mh - pad)) + "px";
  },
  /* kind = "del" | "report" → show that confirm panel; null → back to the item list */
  confirm(kind) {
    if (!this.el) return;
    this.el.querySelectorAll(":scope > .msg-menu-item").forEach((b) => { b.hidden = !!kind; });
    this.el.querySelectorAll("[data-confirm]").forEach((c) => { c.hidden = c.dataset.confirm !== kind; });
  },
  justOpened() { return Date.now() - this._openedAt < 350; },
  close() {
    if (this.el) { this.el.hidden = true; this.el.innerHTML = ""; }
    if (this.rowEl) { this.rowEl.classList.remove("menu-target"); this.rowEl = null; }
    this.forId = null;
  },
};

/* 
   Socket events related functions
*/
function applyEdit({ id, text, editedAt }) {
  const el = rowById(id);
  if (!el || el.classList.contains("deleted")) return;
  exitEdit(el);
  el.dataset.edited = "1";
  el.classList.toggle("no-text", !text);
  const textEl = el.querySelector(".msg-text");
  if (textEl)
    textEl.innerHTML = esc(text || "") +
      ' <span class="msg-edited" title="' + esc("Edited " + fmtMsgFull(editedAt)) + '">(edited)</span>';
}
function applyDelete({ id, byId, byName, byRole }) {
  if (MsgMenu.forId === id) MsgMenu.close();
  const el = rowById(id);
  if (!el) return;
  exitEdit(el);
  el.classList.add("deleted");
  removeMedia(el);
  delete el.dataset.media;
  el.classList.remove("has-media", "no-text");
  el.dataset.delRole = byRole || "";
  el.dataset.delName = byName || "";
  const trigger = el.querySelector(".msg-actions");
  if (trigger) trigger.remove();
  const textEl = el.querySelector(".msg-text");
  if (textEl) {
    textEl.className = "msg-text msg-deleted";
    textEl.innerHTML = "Message deleted" +
      deletedByText({ deletedByRole: byRole, deletedByName: byName });
  }
  regroupChat();
}
function applyClear({ byId, byName }) {
  MsgMenu.close();
  if (mediaRO) mediaRO.disconnect();
  dom.chatMsgs.querySelectorAll(".chat-msg, .chat-loader, .chat-start")
    .forEach((el) => el.remove());
  oldestMsgId = null;
  hasMoreMsgs = false;
  loadingOlder = false;
  startMarkerShown = false;
  addSystemMsg((isMe(byId) ? "You" : (byName || "The host")) + " cleared the chat",
               { silent: isMe(byId) });
  markStartReached();
  reportedIds.clear();
  Unread.toEnd();
}

/* ══════════════════════════════════════
   WIRING — two halves, called from wireEvents() at the ORIGINAL positions
   so document-level listener order is unchanged.
   ══════════════════════════════════════ */
/* the send button / Enter key / log scroll — the early block of wireEvents() */
export function wireChatInput() {
  $("sendBtn").onclick = sendMessage;
  dom.chatInput.addEventListener("input", growChatInput);
  dom.chatInput.addEventListener("keydown", (e) => {
    if (e.isComposing) return;                             // IME candidate, not a send
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  });                                                      // Shift+Enter → newline
  window.addEventListener("resize", () => autoGrow(dom.chatInput));
  dom.chatMsgs.addEventListener("scroll", onChatScroll);
  autoGrow(dom.chatInput);
  /* image links → thumbnails. The strip and any text removal change the composer
     height, so re-measure and keep the log pinned around every change. */
  wireAttachments({
    input: dom.chatInput,
    strip: $("chatAttach"),
    layout: (mutate) => {
      const pinned = Unread.atBottom(8);
      mutate();
      autoGrow(dom.chatInput);
      if (pinned) Unread.toEnd();
    },
  });
  wireGifPicker({ onPick: onGifPicked });
  document.querySelectorAll(".sp-tab").forEach((t) => t.addEventListener("click", closeGifPicker));
  wireLightbox(dom.chatMsgs);                              // .msg-media clicks → fullscreen viewer
  wireSysLog({
    onViewChange: (v) => {
      lockComposer(v === "sys");
      if (v === "chat") requestAnimationFrame(() => { Unread.onChatShown(); SYS.sweep(); });
      else Unread.paint();                                 // hides the jump pill
    },
    onToolsClose: resetClearBtn,                           // closing the host menu cancels a pending confirm
  });
}
/* ── side-panel unread ── — the late block of wireEvents() */
export function wireChatUnread() {
  dom.chatJump.onclick = () => Unread.jump();
  /* the click fires before/after switchTab (from side-tabs.js) depending on order — defer a frame so the
     pane's .active class is already settled */
  dom.tabChat.addEventListener("click", () =>
    requestAnimationFrame(() => { Unread.onChatShown(); SYS.sweep(); onSysPaneShown(); }));
  onTabChange((tab) => { if (tab === "chat") Unread.onChatShown(); });
  document.addEventListener("visibilitychange", () => { Unread.sync(); SYS.sweep(); });
  window.addEventListener("focus", () => Unread.sync());
  Unread.paint();
}
function resetClearBtn() {
  const b = dom.chatClear;
  if (!b) return;
  b.dataset.confirm = "0";
  b.classList.remove("confirm");
  b.title = "Clear chat for everyone";
  clearTimeout(b._t);
}
/* call this again whenever the viewer's role changes (member → mod, etc.) */
export function applyChatPerms() {
  setToolsMode(!!(S.perms && S.perms.isAdmin));            // host → expanding menu; others → Sys toggle
  dom.chatMsgs.querySelectorAll(".chat-msg").forEach((el) => {
    paintRole(el);
  });
}
/* message edit/delete + host clear — wired from room-main after wireChatUnread() */
export function wireChatActions() {
  // menu item clicks (menu lives on <body>)
  MsgMenu.ensure().addEventListener("click", (e) => {
    const item = e.target.closest("[data-act]");
    if (!item) return;
    const id  = MsgMenu.forId;
    const act = item.dataset.act;
    if (act === "edit")            { MsgMenu.close(); enterEdit(rowById(id)); }
    else if (act === "del")        { MsgMenu.confirm("del"); }
    else if (act === "report")     { MsgMenu.confirm("report"); }
    else if (act === "confirm-no") { MsgMenu.confirm(null); }
    else if (act === "del-yes") {
      if (id && getSocket()) sockEmit("chat-delete", { id });
      MsgMenu.close();
    }
    else if (act === "rep-yes") {
      if (id && getSocket()) { sockEmit("chat-report", { id }); reportedIds.add(id); }
      MsgMenu.close();
    }
  });
  // dismissers
  document.addEventListener("click", (e) => {
    if (!MsgMenu.el || MsgMenu.el.hidden) return;
    if (MsgMenu.justOpened()) return;                // ← ignore the post-long-press click
    if (MsgMenu.el.contains(e.target) || e.target.closest(".msg-actions")) return;
    MsgMenu.close();
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") MsgMenu.close(); });
  dom.chatMsgs.addEventListener("scroll", () => MsgMenu.close());
  window.addEventListener("resize", () => MsgMenu.close());
  // host: clear chat (two-click confirm, matching your row-menu pattern)
  if (dom.chatClear) {
    dom.chatClear.addEventListener("click", () => {
      const b = dom.chatClear;
      if (b.dataset.confirm === "1") {
        if (getSocket()) sockEmit("chat-clear");
        resetClearBtn();
        closeChatTools();
      } else {
        b.dataset.confirm = "1";
        b.classList.add("confirm");
        b.title = "Click again to clear for everyone";
        clearTimeout(b._t);
        b._t = setTimeout(resetClearBtn, 3000);
      }
    });
  }
  applyChatPerms();
}
/* ══════════════════════════════════════
   NETWORK — own domain events + centralized hooks.
   socket-core does NOT import this module; we subscribe to it.
   ══════════════════════════════════════ */
let sockWired = false;
onConnect(() => {
  if (sockWired) return;        // 'connect' also fires on reconnect — attach once
  sockWired = true;
  const socket = getSocket();
  socket.on("chat-message", (msg) => appendMessage(msg, true));
  socket.on("chat-system", ({ text, byId }) => addSystemMsg(text, { silent: isMe(byId) }));
  socket.on("chat-edited",  applyEdit);
  socket.on("chat-deleted", applyDelete);
  socket.on("chat-cleared", applyClear);
});
/* phase 20: after applyPerms/renderRoomDetails (10), before queue/video (30).
   Returning the promise makes socket-core await the history fetch, exactly as
   the original `await loadInitialMessages()` did. */
onRoomState(() => {
  addSystemMsg("You joined the room", { silent: true });
  return loadInitialMessages().then(applyChatPerms);   // ← perms are ready by phase 20
}, 20);
onUserJoined(({ username }) => addSystemMsg(username + " joined"));
onUserLeft(({ username }) => addSystemMsg(username + " left"));

/* "Today" becomes "Yesterday" at midnight; relabel once a day */
(function scheduleStampRefresh() {
  const now = new Date();
  const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 5);
  setTimeout(() => {
    dom.chatMsgs.querySelectorAll(".chat-msg").forEach((el) => {
      const t = el.querySelector(".msg-ts");
      if (t) t.textContent = fmtMsgStamp(Number(el.dataset.ts));
    });
    scheduleStampRefresh();
  }, next - now);
})();