/* public/js/permissions.js
 * ─────────────────────────────────────────────────────────────
 * PERMISSIONS, ROOM CONFIG SHEET, MEMBER PROFILE CARD, MODERATION.
 *
 * Three surfaces, one permission model:
 *
 *  A. applyPerms()        the only place that translates S.perms into UI:
 *                         locks the player container, disables play/progress,
 *                         shows the lock chip, paints the gear badge with the
 *                         pending-request count, stops the sync leader, and
 *                         re-renders the queue (permission-gated rows).
 *
 *  B. Config sheet (#cfgSheet)
 *     openConfig/closeConfig/isConfigOpen, renderConfig() — a full innerHTML
 *     rebuild composed of collapsible sections via secOpen()/SEC_CLOSE:
 *       access · sync · requests · queuemode · people · banned · room
 *     Room-details form: roomFormValues/readRoomForm/normRoom/serverRoomVals
 *     drive a draft/dirty/conflict state machine:
 *       S.roomDraft     — in-progress edits, survives perms re-renders
 *       S.roomConflict  — someone else saved while my form was dirty
 *       isRoomDirty() / roomFormError() / syncDirtyUI() — Save/Reset/hint line
 *       applyIncomingRoom() — 'room-updated' → keep my draft, mount conflict
 *     Collapse memory lives in S.cfgCollapsed; the open row menu in S.cfgRowMenu.
 *
 *
 *  Moderation emits (delegated, data-act driven): perm-request, perm-set-mode,
 *  perm-set-queue-mode, perm-respond, perm-grant/perm-revoke, perm-set-role,
 *  member-kick/-ban/-remove (via MOD_EVT), member-unban, room-update.
 *
 *  Network (wirePermissionsSockets, attached on first onConnect):
 *    'room-permissions' → replaces S.perms/S.members/S.requests/S.banned
 *    'room-saved'       → shallow-merges S.room, clears draft+conflict
 *    'room-updated'     → applyIncomingRoom()
 *    'perm-denied' / 'perm-toast' / 'perm-notice' / 'perm-request'
 *  Centralized hooks: onRoomState phase 10 (applyPerms + renderRoomDetails,
 *  before chat's 20 / queue's 30 / player's 35) and onParticipantsUpdate
 *  (the participant count is the validation floor for Max participants).
 *
 *  Cross-module: imports markLocal/revertToRoomState/P from player.js,
 *  Q from queue.js, addSystemMsg from chat.js, renderRoomDetails from
 *  room-details.js. Nothing imports this module — it is a leaf consumer.
 * ───────────────────────────────────────────────────────────── */
"use strict";
import { ROOM_TYPES, ROOM_CAP, ROLE_LABEL, FIELD_LABEL } from "./config.js";   // MOD_EVT → member-profile
import { CHEV_SVG, STEP_UP, STEP_DN, SEC_CLOSE } from "./svg.js";
import { S } from "./state.js";
import { $, dom } from "./dom.js";
import { esc, fmtMsgStamp, toast, isMe } from "./utils.js";                   // fmtJoined → member-profile
import { getSocket, emit as sockEmit } from "./socket-ref.js";
import { onConnect, onRoomState, onParticipantsUpdate } from "./socket-core.js";
import { renderRoomDetails } from "./room-details.js";
import { P, markLocal, revertToRoomState } from "./player.js";
import { Q } from "./queue.js";
import { addSystemMsg, applyChatPerms, jumpToMessage } from "./chat.js";
import { renderTimer } from "./study.js";
import { renderTasks } from "./tasks.js";
import { renderWhiteboardUI } from "./whiteboard.js";
import { nameOf, ensureIdentities } from "../shared/identity.js";
import { scopeTxt, cap, swHTML, cfgAvHTML, memberAvBtnHTML, onModChange } from "./moderation-ui.js";
import { openProfile, refreshProfile } from "./member-profile.js";

/* ═══════════════════════════════════════════
   COLLAPSIBLE SECTION HELPERS
   ═══════════════════════════════════════════ */
/**
 * Opens a collapsible section.
 * @param {string}  id                 stored key in S.cfgCollapsed
 * @param {string}  titleHTML          inner HTML for the <h4> (before the chevron)
 * @param {boolean} [defaultClosed]    initial state when no user toggle yet
 * @param {string}  [extraAttrs]       additional HTML attributes for the <section>
 */
function secOpen(id, titleHTML, defaultClosed, extraAttrs) {
  const closed = S.cfgCollapsed[id] !== undefined
    ? S.cfgCollapsed[id]
    : !!defaultClosed;
  return '<section class="cfg-sec' + (closed ? " collapsed" : "") + '"' +
    ' data-collapsible data-sec-id="' + id + '"' +
    (extraAttrs ? " " + extraAttrs : "") + ">" +
    '<h4 class="cfg-sec-head">' + titleHTML +
      '<span class="cfg-chev">' + CHEV_SVG + "</span></h4>" +
    '<div class="cfg-sec-body"><div class="cfg-sec-inner">';
}
/* ══════════════════════════════════════
   PERMISSIONS UI + ROOM CONFIG SHEET
   ══════════════════════════════════════ */
const participantsHere = () => ((S.room && S.room.participants) || []).length;
const participantFloor = () => Math.max(2, participantsHere());
/* report id whose "Delete message?" confirm is open in the sheet */
let reportConfirm = null;
const isObjId = (s) => /^[a-f0-9]{24}$/i.test(String(s || ""));
/* first blocking problem with the room-details form, or null */
function roomFormError() {
  if (!$("cfgMax")) return null;
  const v = readRoomForm();
  const name = String(v.roomName || "").trim();
  if (name.length < 3)  return { id: "cfgName", msg: "Room name needs at least 3 characters" };
  if (name.length > 60) return { id: "cfgName", msg: "Room name can be 60 characters at most" };
  const here = participantsHere();
  const n = Number(v.maxParticipants);
  if (!Number.isInteger(n)) return { id: "cfgMax", msg: "Max participants must be a whole number" };
  if (n > ROOM_CAP)         return { id: "cfgMax", msg: `Rooms can't hold more than ${ROOM_CAP} people` };
  if (n < 2)               return { id: "cfgMax", msg: "Rooms need space for at least 2 people" };
  if (n < here)            return { id: "cfgMax",
    msg: `${here} ${here === 1 ? "person is" : "people are"} here right now — remove someone first` };
  return null;
}
/* pending requests + open reports, for whoever can act on them */
function paintGearBadge() {
  const p = S.perms || {};
  const req = (p.canGrantSync || p.canGrantQueue) ? S.requests.length : 0;
  const rep = p.canManage ? (S.reports || []).length : 0;
  const n = req + rep;
  dom.gearBadge.classList.toggle("is-hidden", n === 0);
  dom.gearBadge.textContent = n > 99 ? "99+" : n;
}
export function applyPerms() {
  const p = S.perms;
  dom.container.classList.toggle("locked", !p.canSync);
  $("playBtn").disabled     = !p.canSync;
  $("progressBar").disabled = !p.canSync;
  dom.vcLock.style.display  = p.canSync ? "none" : "";
  paintGearBadge();
  if (!p.canSync) P.stopLeader();
  Q.render();
  renderTimer();
  renderTasks();
  renderWhiteboardUI();
}
// Check if the config sheet is open
export const isConfigOpen = () => dom.cfgSheet.classList.contains("open");
/* opts.focus = "reports" → open that section and scroll to opts.reportId */
export function openConfig(opts) {
  opts = (opts && typeof opts === "object" && !(opts instanceof Event)) ? opts : {};
  S.cfgCollapsed = {};          // wipe any per-session toggles → defaults apply
  S.cfgRowMenu   = null;
  reportConfirm  = null;
  if (opts.focus) S.cfgCollapsed[opts.focus] = false;
  renderConfig();
  dom.cfgSheet.classList.add("open");
  dom.cfgBackdrop.classList.add("open");
  dom.cfgSheet.setAttribute("aria-hidden", "false");
  if (opts.focus === "reports") focusReport(opts.reportId);
}
export function closeConfig() {
  S.roomDraft = null;
  S.roomConflict = null;
  reportConfirm = null;
  dom.cfgSheet.classList.remove("open");
  dom.cfgBackdrop.classList.remove("open");
  dom.cfgSheet.setAttribute("aria-hidden", "true");
}
/* scroll a report card into view and flash it */
function focusReport(reportId) {
  const sec = dom.cfgBody.querySelector('[data-sec-id="reports"]');
  if (!sec) return;
  const target = (isObjId(reportId) && sec.querySelector('[data-rid="' + reportId + '"]')) || sec;
  requestAnimationFrame(() => {
    target.scrollIntoView({ block: "nearest", behavior: "smooth" });
    target.classList.remove("cfg-flash");
    void target.offsetWidth;
    target.classList.add("cfg-flash");
    setTimeout(() => target.classList.remove("cfg-flash"), 1800);
  });
}
/* one access row + its request affordance */
function accessRow(label, granted, state, scope, openToAll) {
  let h = '<div class="cfg-row"><span>' + label + "</span>" +
    '<span class="pill ' + (granted ? "pill-ok" : "pill-no") + '">' +
    (granted ? (openToAll ? "Everyone" : "Allowed") : "Host-controlled") + "</span></div>";
  if (granted || !scope) return h;
  if (state === "pending")     h += '<p class="cfg-note">⏳ Requested</p>';
  else if (state === "denied") h += '<p class="cfg-note">🚫 Declined</p>';
  else h += '<button class="cfg-btn primary" data-act="request" data-scope="' + scope +
            '">Request ' + label.toLowerCase() + "</button>";
  return h;
}
export function renderConfig() {
  const p = S.perms, r = S.room || {};
  const online = new Set((r.participants || []).map((x) => (x.userId || "").toString()));
  const host = !!p.isAdmin, mod = !!p.isMod;
  let h = "";
  /* ── your access (non-host) ── */
  if (!host) {
    h += secOpen("access", "Your access");
    if (mod) {
      h += '<div class="cfg-banner"><span class="role-tag role-mod">🛡️ MOD</span>' +
           "<span>You're a mod here</span></div>" +
           accessRow(cap(scopeTxt("sync").label),  true, null, null) +
           accessRow(cap(scopeTxt("queue").label), true, null, null);
    } else {
      h += accessRow(cap(scopeTxt("sync").label),  p.canSync,  p.requestState,      "sync",  p.syncMode  === "everyone");
      h += accessRow(cap(scopeTxt("queue").label), p.canQueue, p.queueRequestState, "queue", p.queueMode === "everyone");
    }
    h += SEC_CLOSE;
  }
  /* ── sync mode (host + mods) ── */
  if (p.canGrantSync) {
    h += secOpen("sync", esc(scopeTxt("sync").modeTitle));          // ← was the hardcoded "Who can play / pause / seek"
    h += '<div class="seg">' +
           '<button class="seg-btn' + (p.syncMode === "host" ? " on" : "") +
             '" data-act="mode" data-mode="host">🔒 Host only</button>' +
           '<button class="seg-btn' + (p.syncMode === "everyone" ? " on" : "") +
             '" data-act="mode" data-mode="everyone">👥 Everyone</button>' +
         "</div>" + SEC_CLOSE;
    if (S.requests.length) {
      h += secOpen("requests", 'Requests <span class="cnt">' + S.requests.length + "</span>");   // ← own id + count badge
      S.requests.forEach((m) => {
        const lbl = scopeTxt(m.scope === "queue" ? "queue" : "sync").short.toLowerCase();
        const nm  = nameOf(m.userId, m.username);
        h += '<div class="cfg-row"><span class="cfg-user">' + cfgAvHTML(nm, m.userId) +
               '<span class="cfg-uname" data-name-uid="' + esc(m.userId) + '">' + esc(nm) + "</span>" +
               '<span class="scope-tag scope-' + (m.scope === "queue" ? "queue" : "playback") + '">' + esc(lbl) + "</span></span>" +
             '<span class="cfg-acts">' +
               '<button class="cfg-mini ok" data-act="respond" data-approve="1" data-scope="' + m.scope + '" data-id="' + m.userId + '">Approve</button>' +
               '<button class="cfg-mini no" data-act="respond" data-approve="0" data-scope="' + m.scope + '" data-id="' + m.userId + '">Deny</button>' +
             "</span></div>";
      });
      h += SEC_CLOSE;
    }
  }
  /* ── reports (host + mods, only when there are any) ── */
  if (p.canManage && (S.reports || []).length) h += reportsSectionHTML();
  /* ── queue mode (host + mods) ── */
  if (p.canGrantQueue) {
    h += secOpen("queuemode", esc(scopeTxt("queue").modeTitle))
    h += '<div class="seg">' +
           '<button class="seg-btn' + (p.queueMode === "host" ? " on" : "") +
             '" data-act="qmode" data-mode="host">🔒 Host &amp; mods</button>' +
           '<button class="seg-btn' + (p.queueMode === "everyone" ? " on" : "") +
             '" data-act="qmode" data-mode="everyone">👥 Everyone</button>' +
         "</div>" + SEC_CLOSE;
  }
  /* ── people (host + mods) ── */
  if (p.canManage) {
    h += secOpen("people", 'People <span class="cnt">' + S.members.length + "</span>", true);
    S.members.forEach((m) => {
      const isHostRow = m.role === "admin";
      const menuOpen  = !!(S.cfgRowMenu && S.cfgRowMenu.id === m.userId);
      const canPerm   = (p.canGrantSync || p.canGrantQueue) && !isHostRow;
      const nm = nameOf(m.userId, m.username);
      h += '<div class="cfg-row"><span class="cfg-user">' +
              memberAvBtnHTML(m) +
              '<button class="cfg-uname cfg-uname-btn" data-act="profile" data-uid="' + m.userId +
                '" data-uname="' + esc(nm) + '" title="View profile">' +
                '<span class="cfg-uname-t" data-name-uid="' + esc(m.userId) + '">' + esc(nm) + "</span>" +
                (online.has(m.userId) ? '<i class="dot-on" title="In room"></i>' : "") +
              "</button>" +
            "</span>" +
            '<span class="cfg-acts">' +
              roleTagHTML(m, p.canSetRoles) +
              (canPerm
                ? '<button class="cfg-more' + (menuOpen ? " on" : "") + '" data-act="row-menu" ' +
                    'data-id="' + m.userId + '" aria-expanded="' + menuOpen + '" ' +
                    'title="Permissions" aria-label="Permissions for ' + esc(nm) + '">⋯</button>'
                : "") +
            "</span></div>";
      if (canPerm && menuOpen) h += permMenuHTML(m, p);
    });
    h += SEC_CLOSE;
  }
  /* ── banned (host only) ── */
  if (p.canBan && S.banned.length) {
    h += secOpen("banned", 'Banned <span class="cnt">' + S.banned.length + "</span>", true);
    S.banned.forEach((b) => {
      h += '<div class="cfg-row"><span class="cfg-user">' + cfgAvHTML(b.username, b.userId) +
             '<span class="cfg-uname" data-name-uid="' + esc(b.userId) + '">' + esc(nameOf(b.userId, b.username)) + "</span></span>" +
           '<span class="cfg-acts">' +
             '<button class="cfg-mini ok" data-act="unban" data-id="' + b.userId + '">Unban</button>' +
           "</span></div>" +
           (b.reason ? '<p class="cfg-note" style="margin-top:0">"' + esc(b.reason) + '"</p>' : "");
    });
    h += '<p class="cfg-note">Can\'t rejoin until unbanned.</p>' + SEC_CLOSE;
  }
  /* ── room details (host + mods → editable) ── */
  if (p.canEditRoom) {
    const f    = roomFormValues();
    const rtCfg = ROOM_TYPES[r.roomType] || ROOM_TYPES.entertainment;
    const tags = parseTags(f.tags);
    const full = tags.length >= 8;
    h += secOpen("room", "Room details", true, 'data-sec="room"');
    if (S.roomConflict) h += conflictHTML(S.roomConflict);
    h += '<label class="cfg-field"><span>Name</span>' +
            '<input id="cfgName" data-room-field type="text" maxlength="60" value="' + esc(f.roomName) + '"></label>' +
         '<label class="cfg-field"><span>Description</span>' +
            '<textarea id="cfgDesc" data-room-field rows="2" maxlength="200">' + esc(f.description) + "</textarea></label>" +
         '<label class="cfg-field"><span>Room type <span class="cfg-note" style="margin:0">(can\'t be changed)</span></span>' +
            '<input type="text" value="' + esc(rtCfg.icon + " " + rtCfg.label) + '" disabled></label>' +
         /* tags: <div>, not <label> — a label would hijack clicks on the chip ✕ buttons */
         '<div class="cfg-field"><span>Tags ' +
            '<span class="cfg-note" id="cfgTagCnt" style="margin:0">' + tags.length + "/8</span></span>" +
            '<input id="cfgTags" data-room-field type="hidden" value="' + esc(tags.join(",")) + '">' +
            '<div class="tag-add">' +
              '<input id="cfgTagIn" type="text" maxlength="24" placeholder="Add a tag" autocomplete="off"' +
                (full ? " disabled" : "") + ">" +
              '<button type="button" class="cfg-mini alt" data-act="tag-add"' + (full ? " disabled" : "") + ">Add</button>" +
            "</div>" +
            '<div class="tag-list" id="cfgTagList">' + tagChipsHTML(tags) + "</div>" +
         "</div>" +
         '<label class="cfg-field"><span>Visibility</span>' +
            '<select id="cfgVis" data-room-field>' +
              '<option value="public"'  + (f.isPublic  ? " selected" : "") + ">Public</option>" +
              '<option value="private"' + (!f.isPublic ? " selected" : "") + ">Private</option>" +
            "</select></label>" +
         '<label class="cfg-field"><span>Max participants ' +
            '<span class="cfg-note" id="cfgMaxHint" style="margin:0">(' + participantsHere() +
              " here now · " + participantFloor() + "–" + ROOM_CAP + ")</span></span>" +
            '<div class="num-stepper">' +
              '<input id="cfgMax" data-room-field type="number" step="1" min="' + participantFloor() +
                '" max="' + ROOM_CAP + '" value="' + f.maxParticipants + '">' +
              '<span class="num-btns">' +
                '<button type="button" class="num-btn" data-act="step-up" tabindex="-1">' + STEP_UP + "</button>" +
                '<button type="button" class="num-btn" data-act="step-down" tabindex="-1">' + STEP_DN + "</button>" +
              "</span></div></label>" +
         '<div class="cfg-actions">' +
            '<button class="cfg-btn primary" id="cfgSave" data-act="save-room">Save changes</button>' +
            '<button class="cfg-btn" id="cfgReset" data-act="reset-room" disabled>Reset</button>' +
         "</div>" +
         '<p class="cfg-dirty is-hidden" id="cfgDirtyNote"></p>';
    h += SEC_CLOSE;
  }
  // ── end of renderConfig ──
  dom.cfgBody.innerHTML = h;
  ensureIdentities([
    ...(S.members || []).map((x) => x.userId),
    ...(S.requests || []).map((x) => x.userId),
    ...(S.banned || []).map((x) => x.userId),
    ...(S.reports || []).flatMap((r) => [r.senderId, ...(r.reporters || []).map((x) => x.userId)]),
  ]);
  syncDirtyUI();
}
/* ── incoming room-details change ── */
function conflictHTML(c) {
  const fields = (c.changed || []).map((k) => FIELD_LABEL[k] || k).join(", ");
  return '<div class="cfg-conflict" role="status">' +
    '<div class="pp-txt"><strong>' + esc(c.by) + "</strong> updated the room" +
      (fields ? " <em>(" + esc(fields) + ")</em>" : "") +
      ". Your edits were kept — save to overwrite, or discard to load theirs.</div>" +
    '<div class="pp-acts">' +
      '<button class="cfg-mini ok" data-act="ack-conflict">OK, keep mine</button>' +
      '<button class="cfg-mini alt" data-act="reset-room">Discard mine</button>' +
    "</div></div>";
}
function mountConflict() {
  const head = dom.cfgBody.querySelector('[data-sec="room"] h4');
  if (!head) return;
  const old = dom.cfgBody.querySelector(".cfg-conflict");
  if (old) old.remove();                              // refresh text if a 2nd edit lands
  head.insertAdjacentHTML("afterend", conflictHTML(S.roomConflict));
}
function nudgeConflict() {
  const el = dom.cfgBody.querySelector(".cfg-conflict");
  if (!el) return;
  el.scrollIntoView({ block: "nearest", behavior: "smooth" });
  el.classList.remove("nudge");
  void el.offsetWidth;                                // restart the animation
  el.classList.add("nudge");
  setTimeout(() => el.classList.remove("nudge"), 600);
}
/* ⚠ shallow-MERGES S.room (property-level, keeps the shared reference valid) */
function applyIncomingRoom(room, by, changed) {
  S.room = Object.assign({}, S.room, room);
  renderRoomDetails();                                // header/title/tags update for everyone
  if (!isConfigOpen() || !isRoomDirty()) {            // nothing to protect → just refresh
    S.roomDraft = null;
    S.roomConflict = null;
    refreshPanels();
    return;
  }
  /* dirty form: keep the draft, queue an acknowledgement */
  const prev = (S.roomConflict && S.roomConflict.changed) || [];
  S.roomConflict = { by, changed: [...new Set([...prev, ...(changed || [])])] };
  mountConflict();
  syncDirtyUI();                                      // blocks Save, shows the warning line
}
/* small inline profile link (name only) */
function profLinkHTML(uid, name, cls = "rep-link") {
  const nm = nameOf(uid, name);
  return '<button type="button" class="' + cls + '" data-act="profile" data-uid="' + esc(uid) +
    '" data-uname="' + esc(nm) + '" title="View profile">' +
    '<span data-name-uid="' + esc(uid) + '">' + esc(nm) + "</span></button>";
}
function reportCardHTML(r) {
  const reps  = r.reporters || [];
  const first = reps[0] || { userId: "", username: "Someone" };
  const more  = reps.length - 1;
  const confirming = reportConfirm === r.id;
  let h = '<div class="rep-card" data-rid="' + esc(r.id) + '">' +
    /* who was reported (avatar + name → profile panel) */
    '<div class="rep-head">' +
      memberAvBtnHTML({ userId: r.senderId, username: r.senderName }) +
      '<div class="rep-who">' +
        profLinkHTML(r.senderId, r.senderName, "cfg-uname cfg-uname-btn rep-name") +
        '<span class="rep-meta">Reported by ' +
          (first.userId ? profLinkHTML(first.userId, first.username) : esc(first.username)) +
          (more > 0
            ? ' <span class="rep-more" title="' + esc(reps.slice(1).map((x) => nameOf(x.userId, x.username)).join(", ")) +
                '">+' + more + " more</span>"
            : "") +
          (r.at ? " · " + esc(fmtMsgStamp(r.at)) : "") +
        "</span>" +
      "</div>" +
      (r.count > 1 ? '<span class="cnt rep-cnt" title="Reports">' + r.count + "</span>" : "") +
    "</div>" +
    /* the reported message; tap to jump to it in the chat */
    '<button class="rep-msg" data-act="report-jump" data-mid="' + esc(r.messageId) +
      '" title="Show in chat">' +
      '<span class="rep-text">' + (r.text ? esc(r.text) : "<em>(no text)</em>") + "</span>" +
      '<span class="rep-go">' +
        (r.messageDeleted ? '<span class="rep-gone">Deleted by the author</span>' : "") +
        "<span>View in chat →</span></span>" +
    "</button>";
  if (confirming) {
    h += '<div class="rep-confirm">' +
           '<div class="pp-txt">Delete this message for everyone?</div>' +
           '<div class="rep-acts">' +
             '<button class="cfg-mini no" data-act="report-del-yes" data-id="' + esc(r.id) +
               '" data-mid="' + esc(r.messageId) + '">Yes, delete</button>' +
             '<button class="cfg-mini alt" data-act="report-del-no">Cancel</button>' +
           "</div></div>";
  } else {
    h += '<div class="rep-acts">' +
           (r.messageDeleted ? "" :
             '<button class="cfg-mini no" data-act="report-del" data-id="' + esc(r.id) + '">🗑 Delete message</button>') +
           '<button class="cfg-mini alt" data-act="report-dismiss" data-id="' + esc(r.id) + '">Dismiss</button>' +
         "</div>";
  }
  return h + "</div>";
}
function reportsSectionHTML() {
  const list = S.reports || [];
  if (reportConfirm && !list.some((r) => r.id === reportConfirm)) reportConfirm = null;
  let h = secOpen("reports", 'Reports <span class="cnt">' + list.length + "</span>");
  list.forEach((r) => { h += reportCardHTML(r); });
  h += '<p class="cfg-note">Tap a message to see it in the chat. Tap a name for kick, remove or ban.</p>';
  return h + SEC_CLOSE;
}
/* "a, #B,b ,c" → ["a","b","c"] — dedupes, strips #, lowercases, caps at 8 */
const parseTags = (v) => [...new Set(
  String(v == null ? "" : v).split(",")
    .map((t) => t.trim().replace(/^#/, "").toLowerCase()).filter(Boolean)
)].slice(0, 8);
/* canonical form of the six editable fields — mirrors the server's sanitizer */
function normRoom(v) {
  return {
    roomName:        String(v.roomName || "").trim().replace(/\s+/g, " "),
    description:     String(v.description || "").trim(),
    tags:            parseTags(v.tags).join(","),
    isPublic:        !!v.isPublic,
    maxParticipants: parseInt(v.maxParticipants, 10) || 0,
  };
}
function tagChipsHTML(tags) {
  return tags.map((t) =>
    '<span class="tag-chip">#' + esc(t) +
      '<button type="button" class="tag-x" data-act="tag-del" data-tag="' + esc(t) +
        '" aria-label="Remove ' + esc(t) + '">✕</button></span>').join("");
}
/* the hidden #cfgTags keeps the comma string, so readRoomForm / isRoomDirty /
   roomDraft work exactly as before — only the visible UI changed */
function setTags(tags) {
  const hid = $("cfgTags");
  if (!hid) return;
  hid.value = tags.join(",");
  $("cfgTagList").innerHTML = tagChipsHTML(tags);
  const full = tags.length >= 8;
  const inp = $("cfgTagIn"), cnt = $("cfgTagCnt");
  const btn = dom.cfgBody.querySelector('[data-act="tag-add"]');
  if (inp) inp.disabled = full;
  if (btn) btn.disabled = full;
  if (cnt) cnt.textContent = tags.length + "/8";
  S.roomDraft = readRoomForm();
  syncDirtyUI();
}
function addTagFromInput() {
  const inp = $("cfgTagIn");
  if (!inp || !inp.value.trim()) return;
  setTags(parseTags($("cfgTags").value + "," + inp.value));   // "a, b" adds both
  inp.value = "";
  inp.focus();
}
/* what's in the DB right now (S.room is kept in sync by room-saved/room-updated) */
function serverRoomVals() {
  const r = S.room || {};
  return normRoom({
    roomName: r.roomName, description: r.description,
    tags: (r.tags || []).join(","), isPublic: r.isPublic !== false,
    maxParticipants: r.maxParticipants || 10,
  });
}
const isRoomDirty = () =>
  !!S.roomDraft && JSON.stringify(normRoom(S.roomDraft)) !== JSON.stringify(serverRoomVals());
function roomFormValues() {
  const r = S.room || {}, d = S.roomDraft || {};
  const pick = (k, fb) => (d[k] !== undefined ? d[k] : fb);
  return {
    roomName:        pick("roomName", r.roomName || ""),
    description:     pick("description", r.description || ""),
    tags:            pick("tags", (r.tags || []).join(", ")),
    isPublic:        pick("isPublic", r.isPublic !== false),
    maxParticipants: pick("maxParticipants", r.maxParticipants || 10),
  };
}
function readRoomForm() {
  return {
    roomName:        $("cfgName").value,
    description:     $("cfgDesc").value,
    tags:            $("cfgTags").value,
    isPublic:        $("cfgVis").value === "public",
    maxParticipants: $("cfgMax").value,
  };
}
/* live state of Reset / Save / the hint line — no re-render, so typing isn't interrupted */
function syncDirtyUI() {
  const reset = $("cfgReset"), save = $("cfgSave"), note = $("cfgDirtyNote"), maxIn = $("cfgMax");
  if (!reset || !save || !note) return;
  /* keep the native clamp honest as people come and go */
  if (maxIn) { maxIn.min = String(participantFloor()); maxIn.max = String(ROOM_CAP); }
  const dirty = isRoomDirty();
  const err   = roomFormError();
  const blocked = !!S.roomConflict || !!err;
  reset.disabled = !dirty;
  dom.cfgBody.querySelectorAll(".invalid").forEach((el) => el.classList.remove("invalid"));
  if (err && $(err.id)) $(err.id).classList.add("invalid");
  note.textContent = S.roomConflict
    ? "⚠️ Someone else changed the room — dismiss the note above, then save."
    : err   ? "⚠️ " + err.msg
    : dirty ? "Unsaved changes" : "";
  note.classList.toggle("warn", blocked);
  note.classList.toggle("is-hidden", !note.textContent);
  save.classList.toggle("is-blocked", blocked);
  save.setAttribute("aria-disabled", blocked ? "true" : "false");
  /* grey out the arrow that would go out of range */
  if (maxIn) {
    const n  = Number(maxIn.value);
    const up = dom.cfgBody.querySelector('[data-act="step-up"]');
    const dn = dom.cfgBody.querySelector('[data-act="step-down"]');
    if (up) up.disabled = Number.isInteger(n) && n >= ROOM_CAP;
    if (dn) dn.disabled = Number.isInteger(n) && n <= participantFloor();
  }
}
function refreshMaxHint() {
  const hint = $("cfgMaxHint");
  if (!hint) return;
  const here = participantsHere();
  hint.textContent = "(" + here + " here now · " + participantFloor() + "–" + ROOM_CAP + ")";
}
function nudgeNote() {
  const note = $("cfgDirtyNote");
  if (!note) return;
  note.classList.remove("nudge"); void note.offsetWidth; note.classList.add("nudge");
  setTimeout(() => note.classList.remove("nudge"), 600);
}
const refreshConfig  = () => { if (isConfigOpen())  renderConfig();  };
const refreshReports = () => {
  if (!isConfigOpen()) return;
  const top = dom.cfgBody.scrollTop;
  renderConfig();
  dom.cfgBody.scrollTop = top;
};
/* anything that used to call refreshConfig() on a server broadcast
   (room-permissions, member list changes, participants changes) should call this */
const refreshPanels  = () => { refreshConfig(); refreshProfile(); };
/* role tag — static for host row / non-role-setters, toggleable otherwise */
function roleTagHTML(m, canSetRoles) {
  if (!canSetRoles || m.role === "admin")
    return '<span class="role-tag role-' + m.role + '">' + ROLE_LABEL[m.role] + "</span>";
  const next = m.role === "mod" ? "member" : "mod";
  return '<button class="role-tag role-' + m.role + ' role-toggle" data-act="role-toggle" ' +
    'data-id="' + m.userId + '" data-role="' + next + '" ' +
    'title="Switch to ' + ROLE_LABEL[next] + '">' + ROLE_LABEL[m.role] +
    '<span class="role-swap">⇄</span></button>';
}
/* ellipsis menu now holds the perm switches (rowMenuHTML stays as-is for the profile panel) */
function permMenuHTML(m, p) {
  const isModRow    = m.role === "mod";
  const syncLocked  = isModRow || p.syncMode  === "everyone" || !p.canGrantSync;
  const queueLocked = isModRow || p.queueMode === "everyone" || !p.canGrantQueue;
  return '<div class="cfg-rowmenu cfg-permmenu">' +
    '<span class="perm-item"><span>' + esc(scopeTxt("sync").short) + "</span>" +
      swHTML("sync",  m.userId, m.canSync,  syncLocked,  scopeTxt("sync").on) + "</span>" +
    '<span class="perm-item"><span>' + esc(scopeTxt("queue").short) + "</span>" +
      swHTML("queue", m.userId, m.canQueue, queueLocked, scopeTxt("queue").on) + "</span>" +
  "</div>";
}
/* delegated actions inside the sheet */
function onCfgClick(e) {
  /* ── collapsible header toggle ── */
  const head = e.target.closest(".cfg-sec-head");
  if (head) {
    const sec = head.closest("[data-collapsible]");
    if (sec) {
      const id      = sec.dataset.secId;
      const opening = sec.classList.contains("collapsed");
      if (opening) {
        /* room details never shares the sheet: opening it closes the rest,
          opening anything else closes it */
        dom.cfgBody.querySelectorAll("[data-collapsible]").forEach((s) => {
          if (s === sec) return;
          const sid = s.dataset.secId;
          if (id === "room" || sid === "room") {
            s.classList.add("collapsed");
            S.cfgCollapsed[sid] = true;
          }
        });
      }
      sec.classList.toggle("collapsed", !opening);
      S.cfgCollapsed[id] = !opening;
      return;
    }
  }
  /* ── data-act buttons ── */
  const el = e.target.closest("[data-act]");
  if (!el || el.tagName === "SELECT" || el.tagName === "INPUT") return;
  const act = el.dataset.act;
  /* number stepper */
  if (act === "step-up" || act === "step-down") {
    const input = $("cfgMax");
    if (!input) return;
    const dir = act === "step-up" ? 1 : -1;
    const min = Number(input.min) || participantFloor();
    const max = Number(input.max) || ROOM_CAP;
    const cur = parseInt(input.value, 10) || min;
    const next = Math.max(min, Math.min(max, cur + dir));
    if (next !== cur) {
      input.value = next;
      input.dispatchEvent(new Event("input", { bubbles: true }));
    }
    return;
  }
  if (act === "profile") { openProfile(el.dataset.uid, el.dataset.uname); return; }
  if (act === "role-toggle") {
    sockEmit("perm-set-role", { userId: el.dataset.id, role: el.dataset.role });
    return;   // 'room-permissions' broadcast re-renders with the new tag
  }
  if (act === "request") sockEmit("perm-request", { scope: el.dataset.scope || "sync" });
  if (act === "mode")    sockEmit("perm-set-mode",       { mode: el.dataset.mode });
  if (act === "qmode")   sockEmit("perm-set-queue-mode", { mode: el.dataset.mode });
  if (act === "respond") sockEmit("perm-respond", {
    userId: el.dataset.id, approve: el.dataset.approve === "1", scope: el.dataset.scope || "sync",
  });
  if (act === "row-menu") {
    const id = el.dataset.id;
    S.cfgRowMenu = (S.cfgRowMenu && S.cfgRowMenu.id === id) ? null : { id, confirm: null };
    renderConfig(); return;
  }
  if (act === "menu-close")  { S.cfgRowMenu = null; renderConfig(); return; }
  if (act === "unban") { sockEmit("member-unban", { userId: el.dataset.id }); return; }
  /* ── reports ── */
  if (act === "report-jump") {
    const mid = el.dataset.mid;
    closeConfig();                                   // the sheet covers the chat on mobile
    jumpToMessage(mid).then((ok) => {
      if (!ok) toast("That message isn't in the chat anymore", "error");
    });
    return;
  }
  if (act === "report-dismiss") {
    el.disabled = true;
    sockEmit("report-dismiss", { id: el.dataset.id });
    return;                                          // 'room-reports' re-renders the list
  }
  if (act === "report-del")    { reportConfirm = el.dataset.id; refreshReports(); return; }
  if (act === "report-del-no") { reportConfirm = null;          refreshReports(); return; }
  if (act === "report-del-yes") {
    el.disabled = true;
    reportConfirm = null;
    sockEmit("chat-delete", { id: el.dataset.mid }); // server resolves the report
    return;
  }
  if (act === "save-room") {
    if (!getSocket()) return;
    if (S.roomConflict) return nudgeConflict();
    addTagFromInput();  // don't lose a half-entered tag
    const payload = readRoomForm();
    S.roomDraft = payload;
    el.disabled = true;
    sockEmit("room-update", payload);
    setTimeout(() => { el.disabled = false; }, 1200);
    return;
  }
  if (act === "reset-room") {
    S.roomDraft = null;
    S.roomConflict = null;
    renderConfig();
    return;
  }
  if (act === "ack-conflict") {
    S.roomConflict = null;
    const b = dom.cfgBody.querySelector(".cfg-conflict");
    if (b) b.remove();
    syncDirtyUI();
    return;
  }
  if (act === "tag-add") { addTagFromInput(); return; }
  if (act === "tag-del") {
    setTags(parseTags($("cfgTags").value).filter((t) => t !== el.dataset.tag));
    return;
  }
}
/* scroll-to-step on the number field */
function onCfgWheel(e) {
  const input = e.target.closest('.num-stepper input[type="number"]');
  if (!input) return;
  e.preventDefault();
  const dir = e.deltaY < 0 ? 1 : -1;
  const min = parseInt(input.min, 10) || 2;
  const max = parseInt(input.max, 10) || 50;
  const cur = parseInt(input.value, 10) || min;
  const next = Math.max(min, Math.min(max, cur + dir));
  if (next !== cur) {
    input.value = next;
    input.dispatchEvent(new Event("input", { bubbles: true }));
  }
}
/* remember room-detail edits so a perms broadcast doesn't wipe the form */
function onCfgRoomInput(e) {
  if (!e.target.closest("[data-room-field]")) return;
  S.roomDraft = readRoomForm();
  syncDirtyUI();                       // Reset lights up immediately
}
function onCfgKeydown(e) {
  if (e.target.id !== "cfgTagIn") return;
  if (e.key === "Enter" || e.key === ",") { e.preventDefault(); addTagFromInput(); }
}
function dom_cfgDelegate() {
  dom.cfgBody.addEventListener("click",  onCfgClick);
  dom.cfgBody.addEventListener("change", onModChange);
  dom.cfgBody.addEventListener("input",  onCfgRoomInput);
  dom.cfgBody.addEventListener("change", onCfgRoomInput);          // selects
  dom.cfgBody.addEventListener("keydown", onCfgKeydown);
  dom.cfgBody.addEventListener("wheel",  onCfgWheel, { passive: false });
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", dom_cfgDelegate, { once: true });
} else {
  dom_cfgDelegate();
}
/* host-side approve/deny prompt */
function showRequestPrompt(userId, username, scope) {
  const key = userId + ":" + scope;
  if (dom.toasts.querySelector('[data-req="' + key + '"]')) return;
  const label = scopeTxt(scope === "queue" ? "queue" : "sync").ask;
  const el = document.createElement("div");
  el.className = "perm-prompt";
  el.dataset.req = key;
  el.innerHTML =
    '<div class="pp-txt"><strong>' + esc(username) + "</strong> wants to " + label + "</div>" +
    '<div class="pp-acts"><button class="cfg-mini ok">Approve</button><button class="cfg-mini no">Deny</button></div>';
  const [ok, no] = el.querySelectorAll("button");
  ok.onclick = () => { sockEmit("perm-respond", { userId, scope, approve: true  }); el.remove(); };
  no.onclick = () => { sockEmit("perm-respond", { userId, scope, approve: false }); el.remove(); };
  dom.toasts.appendChild(el);
  setTimeout(() => el.remove(), 30000);
}
/* host/mod toast: "X reported Y". No message content; View opens the sheet. */
function showReportPrompt({ id, reporterName, senderName }) {
  if (!isObjId(id)) return;
  const txt = "<strong>" + esc(reporterName || "Someone") + "</strong> reported <strong>" +
              esc(senderName || "a message") + "</strong>";
  const existing = dom.toasts.querySelector('[data-report="' + id + '"]');
  if (existing) { existing.querySelector(".pp-txt").innerHTML = "🚩 " + txt; return; }
  const el = document.createElement("div");
  el.className = "perm-prompt report-prompt";
  el.dataset.report = id;
  el.setAttribute("role", "status");
  el.innerHTML =
    '<div class="pp-txt">🚩 ' + txt + "</div>" +
    '<div class="pp-acts">' +
      '<button class="cfg-mini ok">View report</button>' +
      '<button class="cfg-mini alt">Dismiss</button>' +
    "</div>";
  const [view, dismiss] = el.querySelectorAll("button");
  view.onclick    = () => { el.remove(); openConfig({ focus: "reports", reportId: id }); };
  dismiss.onclick = () => el.remove();               // hides the toast; the report stays open
  dom.toasts.appendChild(el);
  setTimeout(() => el.remove(), 20000);
}
/* ══════════════════════════════════════
   WIRING — the gear button / sheet close affordances.
   dom.vcLock lived inside wirePlayerControls() originally; it opens this
   sheet, so it is registered here (player.js must not import openConfig).
   ══════════════════════════════════════ */
export function wirePermissions() {
  dom.configBtn.onclick = () => openConfig();
  $("cfgClose").onclick = closeConfig;
  dom.cfgBackdrop.onclick = closeConfig;
  dom.vcLock.onclick = (e) => { e.stopPropagation(); openConfig(); };
}
/* ══════════════════════════════════════
   NETWORK
   ══════════════════════════════════════ */
let sockWired = false;
export function wirePermissionsSockets() {
  if (sockWired) return;        // 'connect' also fires on reconnect — attach once
  sockWired = true;
  const socket = getSocket();
  /* ── permissions ── */
  socket.on("room-permissions", ({ perms, members, requests, banned }) => {
    const couldReview = !!(S.perms && S.perms.canManage);
    S.perms    = perms;
    S.members  = members  || [];
    S.requests = requests || [];
    S.banned   = banned   || [];
    if (S.cfgRowMenu && !S.members.some((m) => m.userId === S.cfgRowMenu.id)) S.cfgRowMenu = null;
    /* promoted → fetch reports; demoted → forget them */
    if (perms.canManage && !couldReview) sockEmit("report-list");
    if (!perms.canManage && couldReview) {
      S.reports = [];
      dom.toasts.querySelectorAll("[data-report]").forEach((n) => n.remove());
    }
    applyPerms();
    applyChatPerms();
    refreshPanels();
  });
  /* ── reports (server only sends these to host + mods) ── */
  socket.on("room-reports", ({ reports }) => {
    S.reports = Array.isArray(reports) ? reports : [];
    const open = new Set(S.reports.map((r) => r.id));
    dom.toasts.querySelectorAll("[data-report]").forEach((n) => {
      if (!open.has(n.dataset.report)) n.remove();   // resolved elsewhere → drop its toast
    });
    paintGearBadge();
    refreshReports();
  });
  socket.on("report-new", (data) => showReportPrompt(data || {}));
  socket.on("room-saved", ({ room }) => {               // my own save came back
    S.room = Object.assign({}, S.room, room);
    S.roomDraft = null;
    S.roomConflict = null;
    renderRoomDetails();
    refreshPanels();
  });
  socket.on("room-updated", ({ room, by, changed }) => applyIncomingRoom(room, by, changed));
  socket.on("perm-denied", ({ message, video }) => {
    toast(message || "Not allowed", "error");
    if (video) { markLocal(video.currentTime, video.isPlaying); revertToRoomState(video); }
  });
  socket.on("perm-toast", ({ message, type }) => toast(message, type));
  socket.on("perm-notice", ({ text, byId }) => addSystemMsg(text, { silent: isMe(byId) }));
  socket.on("perm-request", ({ userId, username, scope }) => showRequestPrompt(userId, username, scope || "sync"));
}
onConnect(() => wirePermissionsSockets());
/* phase 10 — runs before chat (20), queue (30) and the player's load (35) */
onRoomState(() => {
  applyPerms();
  applyChatPerms();
  renderRoomDetails();
  if (S.perms && S.perms.canManage) sockEmit("report-list");
}, 10);
/* presence moves the validation floor (S.room/details already updated by socket-core) */
onParticipantsUpdate(() => {
  if (isConfigOpen()) { refreshMaxHint(); syncDirtyUI(); }
});