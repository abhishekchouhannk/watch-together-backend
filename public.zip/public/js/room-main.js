/* public/js/room-main.js
 * ─────────────────────────────────────────────────────────────
 * ENTRY POINT / ORCHESTRATOR for the room page.
 *
 * Owns three things and nothing else:
 *   1. the import graph (side-effect imports are what register each feature's
 *      socket listeners and room-state subscriptions),
 *   2. wireEvents() — the truly global/cross-feature listeners plus the
 *      wire*() calls, in the ORIGINAL registration order,
 *   3. the boot sequence, unchanged:
 *        initTheme() → wireEvents() → await fetchMe() → connectSocket()
 *
 * Module graph (one-way, no cycles):
 *   config / svg / state / dom / socket-ref      ← leaves
 *   utils              → config, state, dom
 *   theme              → config, state, dom
 *   room-details       → config, state, dom, utils
 *   socket-core        → config, state, utils, room-details, socket-ref
 *   chat               → config, state, dom, utils, socket-ref, socket-core
 *   player             → config, svg, state, dom, utils, socket-ref, socket-core
 *   voice              → config, dom, player
 *   reactions          → config, state, dom, socket-ref, socket-core, player
 *   queue              → config, state, dom, utils, socket-ref, socket-core,
 *                      player, chat
 *   permissions        → config, svg, state, dom, utils, socket-ref, socket-core,
 *                      room-details, player, queue, chat
 *   permissions.js     → …everything it had…, moderation-ui, member-profile
 *   room-main          → everything
 *   side-tabs          → nothing
 *   moderation-ui.js   → state, utils, socket-ref, shared/identity          (leaf-ish)
 *   member-profile.js  → config, state, dom, utils, socket-ref, socket-core,
                     shared/identity, shared/profile-settings, moderation-ui
 *   voice.js / games.js → member-profile (openProfile) / nothing (data-profile attr) 
 *
 * room-state fan-out phases: 10 permissions · 20 chat (awaited history) ·
 * 30 queue · 35 player. 40 games. Anything that doesn't care omits it and lands on the default 50.
 *
 * fetchMe() lives here because it is session bootstrap, not a feature:
 * it fills S.userId / S.username, which isMe(), chat, reactions and the
 * profile card all read.
 * ───────────────────────────────────────────────────────────── */
"use strict";
import { S } from "./room/state.js";
import { $, dom } from "./room/dom.js";
import { initTheme, closeThemeMenu, wireTheme } from "./room/theme.js";
import { wireRoomDetails } from "./room/room-details.js";
import { connectSocket, leaveRoom } from "./room/socket-core.js";
import { wireChatInput, wireChatUnread, wireChatActions, Unread } from "./room/chat.js";
import { initSideTabs, onTabChange } from "./room/side-tabs.js";
import { wireGames } from "./room/games.js";
import { wirePlayerControls, onFullscreenChange, setPseudoFs } from "./room/player.js";
import { wireReactions, closeRail } from "./room/reactions.js";
import { Q } from "./room/queue.js";
import { wirePermissions, closeConfig } from "./room/permissions.js";
import { wireMemberProfile } from "./room/member-profile.js"
import { wireVoice } from "./room/voice.js";
import { wireFocusMode } from "./room/focus-mode.js";
import "./room/room-layout.js";   // ← registers the roomType → layout switch (phase 5)
import { wireLyrics } from "./room/lyrics.js";
import { wireStudy } from "./room/study.js";
import { wireTasks } from "./room/tasks.js";
import { wireWhiteboard } from "./room/whiteboard.js";
import { initProfileUI } from "./shared/profile-settings.js";
import "./room/identity-socket.js";
import "./room/room-lifecycle.js";
import { startIconEngine } from "./shared/icon-engine.js";

/* Icons first. Excluded = live reactions + user-authored / external text. */
startIconEngine({
  exclude: [
    "#reactRail", "#fxLayer",                              // reactions stay real emoji
    ".msg-text", ".msg-edit",                              // chat messages
    "#hdrName", ".rd-name", ".rd-desc", ".rd-tags",        // room name / description / tags
    "#queueList", "#viTitle", "#viAuthor",                 // video & track titles (external)
    "#unTitle", "#unSub", "#musicTitle", "#musicArtist",
    "#lyricsView", "#lyricsResults",
    ".tk-text",                                            // task text
    "#wbTextLayer", "#wbTabList", "#bpList",               // whiteboard text + board names
    ".prof-bio", ".sl-detail", ".rep-text",                // bios, sys-log details, reported text
    ".toast",
  ],
});

/* ═══════ INIT ═══════ */
document.addEventListener("DOMContentLoaded", async () => {
  initTheme();
  wireEvents();
  await fetchMe();
  connectSocket();
});
initProfileUI({
  chipHost: document.getElementById("meChipHost"),
  root: document.getElementById("roomPage"),      // carries the room theme variables
});
/* ═══════ EVENT WIRING ═══════ */
function wireEvents() {
  /* side-panel tabs: data-driven; the chat-unread reset is the one cross-feature side effect */
  initSideTabs();
  $("backBtn").onclick  = leaveRoom;
  wireChatInput();
  dom.container.addEventListener("touchstart", () => {
    dom.controls.classList.add("show");
    clearTimeout(dom.controls._t);
    dom.controls._t = setTimeout(() => dom.controls.classList.remove("show"), 3000);
  });
  wireRoomDetails();
  wireTheme();
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    closeThemeMenu();
    closeRail();
    closeConfig();
    if (dom.container.classList.contains("pseudo-fs")) setPseudoFs(false);
  });
  wireReactions();
  wireVoice();
  document.addEventListener("fullscreenchange", onFullscreenChange);
  document.addEventListener("webkitfullscreenchange", onFullscreenChange);
  wirePlayerControls();
  wireLyrics();
  wirePermissions();
  wireMemberProfile(); // card delegation + page-wide avatar opener
  wireChatUnread();
  wireChatActions();
  wireStudy();
  wireWhiteboard();
  wireTasks();
  wireGames();
  // add the queue functionality
  Q.wire();
  wireFocusMode();
}
/* ═══════ FETCH ME ═══════ */
async function fetchMe() {
  try {
    const r = await fetch("/api/auth/me", { credentials: "include" });
    if (!r.ok) return;
    const d = await r.json(), u = d.user || d;
    S.userId = (u.id || u._id || "").toString();
    S.username = u.username || "You";
  } catch (_) {}
}